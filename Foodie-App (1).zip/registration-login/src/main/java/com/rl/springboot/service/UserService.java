package com.rl.springboot.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.rl.springboot.model.User;
import com.rl.springboot.web.dto.UserRegistrationDto;

public interface UserService extends UserDetailsService{
	User save(UserRegistrationDto registrationDto);
}
