package com.rl.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegistrationLogin {

	public static void main(String[] args) {
		SpringApplication.run(RegistrationLogin.class, args);
	}

}
